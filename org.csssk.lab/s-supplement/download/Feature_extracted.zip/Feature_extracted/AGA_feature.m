%%new features  ACA/AGA ...,))) 
%  keyboard
clear all;clc
addpath('G:\snoRNA���ݳ���');
aa=txt2mat2('G:\mine_program_matlab\data_snoRNA\RNAfold_Result.txt');
for n=1:length(aa)
    b=aa{n,3};
    s=strfind(b,' ');
    blanket=b(1:s(1)-1);
    string=aa{n,2};
    L1=length(string);
    L2=length(blanket);
    idx=strfind(string, 'AGA'); %%%%
    for i=1:length(idx)
        strb{i}=blanket(idx(i):idx(i)+2);
    end
    n1=0;n2=0;n3=0;n4=0;n5=0;n6=0;n7=0;n8=0;
    for i=1:length(idx)
        if       strcmp(strb(i),'...')==1;  n1=n1+1;
        elseif   strcmp(strb(i),')..')==1;  n2=n1+1;
        elseif   strcmp(strb(i),'.).')==1;  n3=n3+1;
        elseif   strcmp(strb(i),'..)')==1;  n4=n4+1;
        elseif   strcmp(strb(i),')).')==1;  n5=n5+1;
        elseif   strcmp(strb(i),'.))')==1;  n6=n6+1;
        elseif   strcmp(strb(i),').)')==1;  n7=n7+1;
        elseif   strcmp(strb(i),')))')==1;  n8=n8+1;
        end
    end
    sum=n1+n2+n3+n4+n5+n6+n7+n8;
    if sum~=0;
        outFea=[n1/sum, n2/sum,n3/sum,n4/sum,n5/sum,n6/sum,n7/sum,n8/sum];
    else outFea=[0,0,0,0,0,0,0,0];
    end
    
    ACAFea_sca(n,:)=outFea;%%%%
end
AGAFea_snoRNA=ACAFea_sca;
save AGAFea_snoRNA.mat  AGAFea_snoRNA