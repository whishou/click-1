clear;clc
[~,~,snoRNAx]=xlsread('snoRNA.xlsx');
[~,~,snRNAx]=xlsread('snRNA.xlsx');
%%
k=1;
for i=1:size(snoRNAx,1)
    if strcmp(snoRNAx{i,1}(1),'>')==1
        snoRNA_datax(k,1)=snoRNAx(i,3);
    else
        snoRNA_datax(k,2)=snoRNAx(i,1);
        k=k+1;
    end
end
fid = fopen('Temp_RNAfold.txt', 'w'); %%����txt,����RNAfold�ļ���

%%%%%%%����ѡ����תΪtxt��ʽ����RNAfold��ȡ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:length(snoRNA_datax)
    if isempty(snoRNA_datax{j,1});
        break;
    else
        s1=num2str(j); %���ֺ���������ֱ��
        s2=snoRNA_datax{j,2};
        fprintf(fid, '>%s\n',s1); %��һ��Ϊ>+������
        fprintf(fid, '%s\n',s2); % �ڶ���ΪATCG
    end
    clear s1 s2
end
fclose(fid);
copyfile('Temp_RNAfold.txt','G:\RNAfold\Temp_RNAfold.txt');%%���Ƶ�G��

fid=fopen('RNAfold.bat','w');
s1='G:';
s2='cd G:\RNAfold'
s3='RNAfold.exe <Temp_RNAfold.txt >RNAfold_Result.txt';
% s3=strrep(s2,'sss','Ecoli');
fprintf(fid,'%s\n',s1);
fprintf(fid,'%s\n',s2); 
fprintf(fid,'%s\n',s3);
fclose(fid);
dos('RNAfold.bat');
% dos('RNAfold.exe  -noPS  0<Ecoli.txt 1>result.txt')
copyfile('G:\RNAfold\RNAfold_Result.txt','G:\mine_program_matlab\data_snoRNA\RNAfold_Result.txt');%

fid=fopen('RNAfold_Result.txt','r');

kk=1;
while ~feof(fid);
    tline=fgetl(fid);
    if strfind(tline,'.')>0; tline=deblank(tline);
        posi=strfind(tline,' ');
        d=tline(posi(1)+2:end-1); %%��ȡenergyֵ
        MFEvalue(kk,1)=str2num(d);
        string=tline(1:posi(1)-1);
        MFEmean(kk,1)=str2num(d)/length(string);
        kk=kk+1;
    end
end
% save snoRNA_MFEvalue_MFEmean.mat MFEvalue MFEmean
%%  Triplet
copyfile('G:\mine_program_matlab\data_snoRNA\RNAfold_Result.txt','G:/triplet/Temp_triplet.txt');%%���Ƶ�F��
fid=fopen('triplet.bat','w');
s1='G:';
s2='cd G:\triplet';
s3='perl triplet_svm_classifier.pl Temp_triplet.txt predict_format.txt  ';
% s4=strrep(s3,'sss','result');
fprintf(fid,'%s\n',s1); fprintf(fid,'%s\n',s2); fprintf(fid,'%s\n',s3);%fprintf(fid,'%s\n',s4);
fclose(fid);
dos('triplet.bat');

addpath('G:\snoRNA���ݳ���')
TripF=load('G:\triplet\3.txt');
mat2txt=txt2mat('G:\triplet\2.txt');
%         keyboard

for i=1:length(mat2txt)
    st1=mat2txt{i,1};
    idx1=strfind(st1,'>');
    idx2=strfind(st1,'_');
    stc(i,1)=str2num(st1(idx1+1:idx2(1)-1));
end

st2=stc(TripF(:,end),:);
b2=unique(st2);

% keyboard
for jj=1:length(b2)
    idx=find(st2(:,1)==b2(jj));
    if length(idx)==1;
    TripFea(jj,:)=TripF(idx,:); 
    else
    TripFea(jj,:)=sum(TripF(idx,:));
    end
end

if length(b2)<length(snoRNA_datax);
    idx4=setdiff(1:length(snoRNA_datax),b2);
    TripFea=TripFea(:,1:end-1);
else
    idx4=[];
    TripFea=TripFea(:,1:end-1);
end
Trip_snoRNA=TripFea;
idx_snoRNA=idx4;
% save Trip_snoRNA_idx.mat Trip_snoRNA idx_snoRNA