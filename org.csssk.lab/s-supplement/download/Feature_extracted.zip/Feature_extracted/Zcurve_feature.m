clear all;
clc
addpath('G:\snoRNA���ݳ���')
snoRNA_sca=txt2mat('snoRNA_.txt');

for i=1:length(snoRNA_sca)
    trainsamP{i,1}=snoRNA_sca{i,2};
end


% NON_HACA=txt2mat('sca_N_HACA.txt');
%
% for i=1:length(NON_HACA)
%     trainsamN{i,1}=NON_HACA{i,2};
% end
% addpath('G:\mine_program_matlab\matlab_program\matlab_zcurve');
addpath('G:\mine_program_matlab\matlab_program\zcurve');
[roweg,lineeg]=size(trainsamP);
i=0;
for h=1:length(trainsamP);
    i=i+1
    essse=deblank(trainsamP(h,1));
    essse=essse{1};
    essse=upper(essse);
    essse=regexprep(essse,'U','T');
    [roweg,lineeg]=size(essse);
    %     %         [parameter6 pattern]=zeven(essse,6); %��������������ͬʱ���ֵĴ���
    %     %         egeven6(i,:)=parameter6;
    %     %         egpattern6{i}=pattern;
    %     %
    [Xexmi, Yexmi, Zexmi]=ztransform(essse); %exmi means the EXtron Mononucleotides phase-Independent
    scadataPmi(h,:)=[Xexmi, Yexmi, Zexmi];
    scadataPms(h,:)=mosztrans(essse);
    scadataPdi(h,:)=diiztrans(essse); %exdii means EXtron Di-nucleotides phase-Independent˫������λ
    scadataPds(h,:)=disztrans(essse);
    scadataPti(h,:)=triiztrans(essse); %exti means EXtron Tri-nucleotides phase-Independent��������λ
    scadataPts(h,:)=trisztrans(essse);
    %     [parameter6, ~]=zeven(essse,6); %��������������ͬʱ���ֵĴ���
    parameter6=vwzcurve(essse,6);
    scadataPeven6(h,:)=parameter6;
    
    
end





% [roweg,lineeg]=size(trainsamN);
% i=0;
% for h=1:roweg
%     i=i+1
%     essse=deblank(trainsamN(h,1));
%     essse=essse{1};
%     essse=upper(essse);
%         essse=regexprep(essse,'U','T');
%     [roweg,lineeg]=size(essse);
%     [Xexmi, Yexmi, Zexmi]=ztransform(essse); %exmi means the EXtron Mononucleotides phase-Independent
%     scadataNmi(h,:)=[Xexmi, Yexmi, Zexmi];
%     scadataNms(h,:)=mosztrans(essse);
%     scadataNdi(h,:)=diiztrans(essse); %exdii means EXtron Di-nucleotides phase-Independent˫������λ
%     scadataNds(h,:)=disztrans(essse);
%     scadataNti(h,:)=triiztrans(essse); %exti means EXtron Tri-nucleotides phase-Independent��������λ
%     scadataNts(h,:)=trisztrans(essse);
%         [parameter6 pattern]=zeven(essse,6); %��������������ͬʱ���ֵĴ���
%          scadataNeven6(h,:)=parameter6;
% end

save Zcurve_snoRNA.mat  scadataPmi scadataPms scadataPdi scadataPds scadataPti scadataPts scadataPeven6
% save Zcurve_N_sca.mat  scadataNmi scadataNms scadataNdi scadataNds scadataNti scadataNts scadataNeven6













