function [Q,W,C,D,T,Z,A]=spls(X,Y,h,lambda1,lambda2)
%# Function [Q,W,C,D,T,Z,A]=spls(X,Y,h,lambda1,lambda2)
%#  Author: GQ Zheng 
%# AIM:         performs SPLS calibration on X and Y

%#
%# INPUT:
%# X            matrix of independent variables (e.g. spectra) (n x p)
%# Y            vector of y reference values (n x 1)
%# h            number of SPLS factors to consider
%# preproc      preprocessing applied to data
%#              0: no preprocessing
%#              1: column mean-centering of X and Y
%#
%# OUTPUT:
%# B           regression coefficients (p x 1)
%# W            X-weights (p x A)
%# T            scores (n x A)
%# P            X-loadings (p x A)
%# Q            Y-loadings (A x 1)
%# R2X          percentage of X variance explained by each PLS factor
%# R2Y          percentage of Y-variance explained by each PLS factor

[n,mx]=size(X);
[n,my]=size(Y);
if h>mx
    h=mx;
end

if h==0
    disp('No 0 latent')
else
    C=zeros(mx,h);  %
    D=zeros(my,h);  %
    T=zeros(n,h);   %
    Z=zeros(n,h);   %
    W=zeros(mx,h);  %
    
    for k=1:h
        M=X'*Y;
        [U,DD,V]=svd(M);
        uu=U(:,1);vv=V(:,1);
        if vv<0
            vold=-vv;uold=-uu;
        else
            vold=vv;uold=uu;
        end
        e=0.000001;
        e0=1;
        while e0>e
            Lambda=lambda1;
            u1=sign(M*vold).*max(abs(M*vold)-Lambda,0);
            unew=u1./sqrt(u1'*u1);
            v1=sign(M'*uold).*max(abs(M'*uold)-lambda2,0);
            vnew=v1./sqrt(v1'*v1);
            
            e0=norm(unew-uold)/norm(unew);
            uold=unew;vold=vnew;
        end
        W(:,k)=unew;
        t=X*unew./(unew'*unew);
        q=Y'*t./(t'*t);
        z=Y*vnew./(vnew'*vnew);
        c=t'*X./(t'*t);
        c=c';
        d=t'*Y./(t'*z);
        d=d';
        C(:,k)=c;
        D(:,k)=d;
        T(:,k)=t;
        Z(:,k)=z;
        Q(:,k)=q;
        E=X-t*c';
        X=E;
        F=Y-t*d';
        Y=F;
        %      lambda=0.1;
        %      ridi=eye(mx);
        %      Beta = inv(X'*X + ridi*lambda)*X'*Y;
        %
    end
end
for i=1:h
    
    if i==1
        whh=eye(mx,mx);
    else
        whh=whh*(eye(mx,mx)-W(:,i-1)*C(:,i-1)');
    end
    wh=whh*W(:,i);
    WH(:,i)=wh;
end
A=Q(:,1:h)*WH';

A=A';


