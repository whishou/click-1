clear all;clc
tic
addpath('lars');
load 'snoRNAs_data.mat';
load 'non_snoRNAs_data.mat';
train_non_snoRNA_temp=snoRNAs_data;
train_snoRNA_temp=non_snoRNAs_data;
clearvars -EXCEPT train_non_snoRNA_temp train_snoRNA_temp
load 'data_snoRNA.mat';
load 'data_snRNA.mat';
X=[train_snoRNA_temp
    train_non_snoRNA_temp];

y=[ones(size(train_snoRNA_temp),1)
    -1*ones(size(train_non_snoRNA_temp),1)];
[x,mt,Std]=autosc(X);

lambda2=0.1; stop=-200;
beta = larsen(x, y, lambda2, stop);% the elastic net
ifdx=find(beta(end,:)~=0);
train_non_snoRNA_temp=train_non_snoRNA_temp(:,ifdx);
train_snoRNA_temp=train_snoRNA_temp(:,ifdx);
test_snoRNA_temp=data_snoRNA(:,ifdx);
test_snRNA_temp=data_snRNA(:,ifdx);
clearvars -EXCEPT train_non_snoRNA_temp train_snoRNA_temp test_snoRNA_temp test_snRNA_temp
%%
if size(train_snoRNA_temp,1)<=size(train_non_snoRNA_temp,1)
    egall=train_snoRNA_temp;
    nonall=train_non_snoRNA_temp;
else
    egall=train_non_snoRNA_temp;
    nonall=train_snoRNA_temp;
end
% random samples
train_snoRNA_tempx=egall(randperm(size(egall,1)),:);

nonall=nonall(randperm(size(nonall,1)),:);
train_non_snoRNA_tempx=nonall(randperm(size(egall,1)),:);
% %test dataset
if size(test_snoRNA_temp,1)<=size(test_snRNA_temp,1)
    egall=test_snoRNA_temp;
    nonall=test_snRNA_temp;
else
    egall=test_snRNA_temp;
    nonall=test_snoRNA_temp;
end
% random samples
test_snRNA_tempx=egall(randperm(size(egall,1)),:);

nonall=nonall(randperm(size(nonall,1)),:);
test_snoRNA_tempx=nonall(randperm(size(egall,1)),:);
clearvars -EXCEPT test_snRNA_tempx  test_snoRNA_tempx train_snoRNA_tempx train_non_snoRNA_tempx
%%
step=5;
num=fix(size(train_snoRNA_tempx,1)/step);
index=1:size(train_snoRNA_tempx,1);

for h=1:20
    for k=1:step
        
        xtest_snoRNA=train_snoRNA_tempx(index((k-1)*num+1:k*num),:);      %in the databases are randomly divided...
        xtest_non_snoRNA=train_non_snoRNA_tempx(index((k-1)*num+1:k*num),:);
        
        xtrain_snoRNA=train_snoRNA_tempx;
        xtrain_snoRNA(index((k-1)*num+1:k*num),:)=[];      %the positive and negative sequences ...
        
        xtrain_non_snoRNA=train_non_snoRNA_tempx;
        xtrain_non_snoRNA(index((k-1)*num+1:k*num),:)=[];   %into two identical parts:training part and testing part
        
        ytrain=[ones(size(xtrain_snoRNA,1),1)
            -1*ones(size(xtrain_non_snoRNA,1),1)];
        
        xtrain_temp=[xtrain_snoRNA
            xtrain_non_snoRNA];
        xtest_temp=[xtest_snoRNA
            xtest_non_snoRNA];
        test_data_temp=[test_snoRNA_tempx
            test_snRNA_tempx];
        %%
        idx1=find(abs(sum(xtrain_temp))==0);
        idx2=find(abs(sum(xtest_temp))==0);
        idx3=find(abs(sum(test_data_temp))==0);
        idx4=union(union(idx1,idx2),idx3);
        xtrain_temp(:,idx4)=[];
        xtest_temp(:,idx4)=[];
        test_data_temp(:,idx4)=[];
        idx5=setdiff(1:size(train_snoRNA_tempx,2),idx4);
        %%
        [xtrain,mtrain,stdtrain]=autosc(xtrain_temp);
        
        xtest=scal(xtest_temp,mtrain,stdtrain);
        
        test_data_tempx=scal(test_data_temp,mtrain,stdtrain);
        
        ytest=[ones(size(xtest_snoRNA,1),1)
            -1.*ones(size(xtest_non_snoRNA,1),1)];
        
        ydata_test=ones(size(test_data_tempx,1),1);
        
        maxh1=rank(xtrain);
        maxh=min(100,maxh1);
        
        %%
        
        %[A,W,Q,P,B,T]=nipals(xtrain,ytrain,h);
        %       LDA=plslda(xtrain,ytrain,h);
        LDA=splslda(xtrain,ytrain,h,'autoscaling',-0.5,-0.5);
        A=LDA.regression_coef';
        tempB(k,idx5)=A; tempB(k,idx4)=0;
        ypred=xtest*A';
        yclass_xtest=sign(ypred);
        xtest_TP(k,h)=size(find(yclass_xtest(1:size(xtest_snoRNA,1),1).*ones(size(xtest_snoRNA,1),1)==1),1); %true positive
        xtest_FN(k,h)=size(find(yclass_xtest(1:size(xtest_snoRNA,1),1).*ones(size(xtest_snoRNA,1),1)==-1),1); %false negative
        xtest_sn(k,h)=xtest_TP(k,h)/(xtest_TP(k,h)+xtest_FN(k,h));
        xtest_TN(k,h)=size(find(yclass_xtest(size(xtest_snoRNA,1)+1:length(yclass_xtest),1).*(-1*ones(size(xtest_non_snoRNA,1),1))==1),1); %true negative
        xtest_FP(k,h)=size(find(yclass_xtest(size(xtest_snoRNA,1)+1:length(yclass_xtest),1).*(-1*ones(size(xtest_non_snoRNA,1),1))==-1),1); %false positive
        xtest_sp(k,h)=xtest_TN(k,h)/(xtest_TN(k,h)+xtest_FP(k,h));
        xtest_ac(k,h)=(xtest_TP(k,h)+xtest_TN(k,h))/(xtest_TP(k,h)+xtest_FN(k,h)+xtest_TN(k,h)+xtest_FP(k,h));
        %test
        ypred_test=test_data_tempx*A';
        yclass_test=sign(ypred_test);
        test_TP(k,h)=size(find(yclass_test(1:size(test_snoRNA_tempx,1),1).*ones(size(test_snoRNA_tempx,1),1)==1),1); %true positive
        test_FN(k,h)=size(find(yclass_test(1:size(test_snoRNA_tempx,1),1).*ones(size(test_snoRNA_tempx,1),1)==-1),1); %false negative
        test_sn(k,h)=test_TP(k,h)/(test_TP(k,h)+test_FN(k,h));
        test_TN(k,h)=size(find(yclass_test(size(test_snoRNA_tempx,1)+1:length(yclass_test),1).*(-1*ones(size(test_snRNA_tempx,1),1))==1),1); %true negative
        test_FP(k,h)=size(find(yclass_test(size(test_snoRNA_tempx,1)+1:length(yclass_test),1).*(-1*ones(size(test_snRNA_tempx,1),1))==-1),1); %false positive
        test_sp(k,h)=test_TN(k,h)/(test_TN(k,h)+test_FP(k,h));
        test_ac(k,h)=(test_TP(k,h)+test_TN(k,h))/(test_TP(k,h)+test_FN(k,h)+test_TN(k,h)+test_FP(k,h));
        % xtrain
        ypre_xtrain=xtrain*A';
        yclass_xtrain=sign(ypre_xtrain);
        xtrain_TP(k,h)=size(find(yclass_xtrain(1:size(xtrain_snoRNA,1),1).*ones(size(xtrain_snoRNA,1),1)==1),1); %true positive
        xtrain_FN(k,h)=size(find(yclass_xtrain(1:size(xtrain_snoRNA,1),1).*ones(size(xtrain_snoRNA,1),1)==-1),1); %false negative
        xtrain_sn(k,h)=xtrain_TP(k,h)/(xtrain_TP(k,h)+xtrain_FN(k,h));
        xtrain_TN(k,h)=size(find(yclass_xtrain(size(xtrain_snoRNA,1)+1:length(yclass_xtrain),1).*ones(size(xtrain_non_snoRNA,1),1)==1),1); %true negative
        xtrain_FP(k,h)=size(find(yclass_xtrain(size(xtrain_snoRNA,1)+1:length(yclass_xtrain),1).*ones(size(xtrain_non_snoRNA,1),1)==-1),1); %false positive
        xtrain_sp(k,h)=xtrain_TN(k,h)/(xtrain_TN(k,h)+xtrain_FP(k,h));
        xtrain_ac(k,h)=(xtrain_TP(k,h)+xtrain_TN(k,h))/(xtrain_TP(k,h)+xtrain_FN(k,h)+xtrain_TN(k,h)+xtrain_FP(k,h));
    end
end
[max_snoRNAxx,i1]=max(xtest_sn);
[xmax_snoRNA,i2]=max(max_snoRNAxx);
ind_row=i1(i2);
ind_col=i2;

test_sn_optimal=test_sn(ind_row,ind_col);
test_sp_optimal=test_sp(ind_row,ind_col);
test_ac_optimal=test_ac(ind_row,ind_col);

xtest_sn_optimal=xtest_sn(ind_row,ind_col);
xtest_sp_optimal=xtest_sp(ind_row,ind_col);
xtest_ac_optimal=xtest_ac(ind_row,ind_col);

xtrain_sn_optimal=xtrain_sn(ind_row,ind_col);
xtrain_sp_optimal=xtrain_sp(ind_row,ind_col);
xtrain_ac_optimal=xtrain_ac(ind_row,ind_col);

results=[xtrain_sn_optimal xtrain_sp_optimal xtrain_ac_optimal xtest_sn_optimal xtest_sp_optimal xtest_ac_optimal test_sn_optimal test_sp_optimal test_ac_optimal].*100
% save parameter1.mat ypred ypred_test ypre_xtrain results 
%
toc
